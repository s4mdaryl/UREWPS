module.exports = {
  skipFiles: ["test/CustomERC20Mock.sol","test/ERC20Mock.sol","test/Imports.sol","test/PrimeToken.sol", "utils/Multicall.sol"]
};
